package br.com.agendafacil.model;

public enum StatusUsuario {
    ATIVO, INATIVO
}
