package br.com.agendafacil.model;

public enum TipoNotificacao {
    NOVO_AGENDAMENTO, LEMBRETE, CANCELAMENTO, REMARCACAO, CONFIRMACAO
}
