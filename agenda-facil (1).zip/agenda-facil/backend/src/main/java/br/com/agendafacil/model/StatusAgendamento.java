package br.com.agendafacil.model;

public enum StatusAgendamento {
    PENDENTE, CONFIRMADO, CANCELADO, REALIZADO
}
