package br.com.agendafacil.app.ui.cliente

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import br.com.agendafacil.app.data.SessionData
import br.com.agendafacil.app.ui.*
import br.com.agendafacil.app.ui.common.NotifVM
import br.com.agendafacil.app.ui.common.NotificacoesScreen
import br.com.agendafacil.app.ui.common.ProfileScreen

@Composable
fun ClienteShell(session: SessionData) {
    val uid = session.usuario.id
    val booking: BookingVM = userVm(uid)
    val notif: NotifVM = userVm(uid)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showNotif by rememberSaveable { mutableStateOf(false) }

    val items = listOf(
        NavItem("Início", Icons.Filled.Home), NavItem("Agendar", Icons.Filled.CalendarMonth),
        NavItem("Meus", Icons.Filled.Schedule), NavItem("Perfil", Icons.Filled.Person)
    )

    BackHandler(enabled = showNotif || tab != 0) {
        when {
            showNotif -> showNotif = false
            tab == 1 && booking.resultado == null && booking.step > 1 -> booking.voltar()
            else -> tab = 0
        }
    }

    Scaffold(
        containerColor = C.Bg,
        bottomBar = { if (!showNotif) AppBottomBar(items, tab) { tab = it } }
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            if (showNotif) NotificacoesScreen(notif, onClose = { showNotif = false })
            else when (tab) {
                0 -> HomeTab(
                    session,
                    onOpenProfile = { tab = 3 },
                    onVerTodos = { tab = 2 },
                    onCategoria = { cat -> booking.iniciarPorCategoria(cat); tab = 1 },
                    onServico = { s -> booking.iniciarComServico(s); tab = 1 }
                )
                1 -> BookingTab(booking, onGoMeus = { tab = 2 })
                2 -> MeusTab(uid)
                else -> ProfileScreen(session, onNotifications = { showNotif = true })
            }
        }
    }
}
