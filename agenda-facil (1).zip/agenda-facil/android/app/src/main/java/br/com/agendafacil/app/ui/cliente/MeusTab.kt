package br.com.agendafacil.app.ui.cliente

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.agendafacil.app.data.*
import br.com.agendafacil.app.ui.*
import kotlinx.coroutines.launch
import java.time.LocalDate

class MeusVM : ViewModel() {
    var tipo by mutableStateOf("proximos")
    var working by mutableStateOf(false)
    val lista = Resource(viewModelScope) { meusAgendamentos(tipo) }

    fun trocarTipo(t: String) {
        if (t == tipo) return
        tipo = t; lista.reset(); lista.load()
    }

    fun cancelarAg(a: AgendamentoDto) {
        viewModelScope.launch {
            working = true
            Api.call { cancelarCliente(a.id) }
                .fold({ Graph.toast("Agendamento cancelado"); lista.load() }, { Graph.toast(it.message ?: "Erro ao cancelar") })
            working = false
        }
    }

    fun remarcarAg(a: AgendamentoDto, data: LocalDate, hora: String, onOk: () -> Unit) {
        viewModelScope.launch {
            working = true
            Api.call { remarcarCliente(a.id, RemarcarReq(data.toString(), hora)) }
                .fold({ Graph.toast("Agendamento remarcado"); onOk(); lista.load() }, { Graph.toast(it.message ?: "Erro ao remarcar") })
            working = false
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MeusTab(userId: Long) {
    val vm: MeusVM = userVm(userId)
    LaunchedEffect(Unit) { vm.lista.load() }
    val refreshing by vm.lista.refreshing.collectAsState()
    var cancelando by remember { mutableStateOf<AgendamentoDto?>(null) }
    var remarcando by remember { mutableStateOf<AgendamentoDto?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenTitle("Seus Agendamentos", "Puxe para atualizar dados") {
            IconButton(onClick = { vm.lista.load() }) { Icon(Icons.Filled.Refresh, "Atualizar", tint = C.Primary) }
        }
        TabRow(
            selectedTabIndex = if (vm.tipo == "proximos") 0 else 1, containerColor = androidx.compose.ui.graphics.Color.Transparent,
            contentColor = C.Primary, divider = { HorizontalDivider(color = C.Border) }
        ) {
            Tab(selected = vm.tipo == "proximos", onClick = { vm.trocarTipo("proximos") }, text = { Text("Próximos", fontWeight = FontWeight.SemiBold) },
                selectedContentColor = C.Primary, unselectedContentColor = C.Muted)
            Tab(selected = vm.tipo == "historico", onClick = { vm.trocarTipo("historico") }, text = { Text("Histórico", fontWeight = FontWeight.SemiBold) },
                selectedContentColor = C.Primary, unselectedContentColor = C.Muted)
        }
        Spacer(Modifier.height(12.dp))
        PullToRefreshBox(isRefreshing = refreshing, onRefresh = { vm.lista.load() }, modifier = Modifier.weight(1f)) {
            ResourceView(vm.lista) { lista ->
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (lista.isEmpty()) EmptyState(if (vm.tipo == "proximos") "Você não possui agendamentos próximos." else "Nenhum atendimento no histórico.")
                    lista.forEach { a ->
                        AgendamentoCard(a, acoes = vm.tipo == "proximos",
                            onRemarcar = { remarcando = a }, onCancelar = { cancelando = a })
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }

    cancelando?.let { a ->
        ConfirmDialog("Cancelar agendamento", "Deseja cancelar ${a.servico} em ${a.data.toDate().fmtShort()} às ${a.horaInicio}?", "Cancelar agendamento",
            { vm.cancelarAg(a); cancelando = null }, { cancelando = null })
    }
    remarcando?.let { a -> RemarcarDialog(a, vm, onClose = { remarcando = null }) }
}

@Composable
private fun AgendamentoCard(a: AgendamentoDto, acoes: Boolean, onRemarcar: () -> Unit, onCancelar: () -> Unit) {
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Pill(a.servico, C.CyanBg, C.Primary)
            Spacer(Modifier.weight(1f))
            StatusChip(a.status)
        }
        Spacer(Modifier.height(10.dp))
        Text("Profissional: ${a.profissional}", fontWeight = FontWeight.Bold, fontFamily = Outfit, fontSize = 16.sp, color = C.Text)
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.CalendarMonth, null, tint = C.Muted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("${a.data.toDate().fmtLonga()} - ${a.horaInicio}", fontSize = 13.sp, color = C.Muted)
        }
        Text(a.valor.brl(), fontSize = 13.sp, color = C.Primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
        if (acoes && (a.status == "PENDENTE" || a.status == "CONFIRMADO")) {
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = C.Border)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppButton("Remarcar", onRemarcar, Modifier.weight(1f), kind = BtnKind.Soft)
                AppButton("Cancelar", onCancelar, Modifier.weight(1f), kind = BtnKind.Danger)
            }
        }
    }
}

@Composable
private fun RemarcarDialog(a: AgendamentoDto, vm: MeusVM, onClose: () -> Unit) {
    var data by remember { mutableStateOf<LocalDate?>(null) }
    var hora by remember { mutableStateOf<String?>(null) }
    AppDialog("Remarcar ${a.servico}", onClose) {
        Text("Profissional: ${a.profissional}", color = C.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        SlotPicker(a.profissionalId, a.servicoId, a.id, data, hora, 0, { data = it }, { hora = it })
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppButton("Voltar", onClose, Modifier.weight(1f), kind = BtnKind.Soft)
            AppButton("Confirmar", { val d = data; val h = hora; if (d != null && h != null) vm.remarcarAg(a, d, h, onClose) },
                Modifier.weight(1f), enabled = data != null && hora != null, loading = vm.working)
        }
    }
}
