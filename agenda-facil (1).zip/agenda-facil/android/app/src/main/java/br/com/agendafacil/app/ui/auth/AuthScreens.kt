package br.com.agendafacil.app.ui.auth

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import br.com.agendafacil.app.data.Api
import br.com.agendafacil.app.data.Graph
import br.com.agendafacil.app.data.LoginReq
import br.com.agendafacil.app.data.RegisterReq
import br.com.agendafacil.app.ui.*
import kotlinx.coroutines.launch

class AuthVM : ViewModel() {
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)

    fun entrar(email: String, senha: String, perfil: String) {
        if (email.isBlank() || senha.isBlank()) { error = "Informe e-mail e senha"; return }
        viewModelScope.launch {
            loading = true; error = null
            Api.call { login(LoginReq(email.trim(), senha, perfil)) }
                .fold({ Graph.session.save(it) }, { error = it.message })
            loading = false
        }
    }

    fun cadastrar(nome: String, email: String, telefone: String, senha: String, confirmacao: String) {
        error = when {
            nome.isBlank() || email.isBlank() || senha.isBlank() -> "Preencha os campos obrigatórios"
            !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "E-mail inválido"
            senha.length < 6 -> "A senha deve ter no mínimo 6 caracteres"
            senha != confirmacao -> "As senhas não conferem"
            else -> null
        }
        if (error != null) return
        viewModelScope.launch {
            loading = true
            Api.call { registrar(RegisterReq(nome.trim(), email.trim(), telefone.trim().ifBlank { null }, senha)) }
                .fold({ Graph.session.save(it) }, { error = it.message })
            loading = false
        }
    }
}

@Composable
private fun Logo() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(56.dp).background(C.Primary, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.EventAvailable, null, tint = Color.White, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(12.dp))
        Text("AgendaFácil", fontFamily = Outfit, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = C.Title)
    }
}

@Composable
fun LoginScreen(onRegister: () -> Unit, vm: AuthVM = viewModel()) {
    val perfis = listOf("CLIENTE" to "Cliente", "PROFISSIONAL" to "Profissional", "ADMINISTRADOR" to "Administrador")
    var perfil by rememberSaveable { mutableStateOf("CLIENTE") }
    var email by rememberSaveable { mutableStateOf("") }
    var senha by rememberSaveable { mutableStateOf("") }
    var esqueci by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        Logo()
        Spacer(Modifier.height(10.dp))
        Text("Agende seus serviços com facilidade", color = C.Muted, fontSize = 14.sp)
        Spacer(Modifier.height(32.dp))

        Surface(shape = RoundedCornerShape(14.dp), color = Color.White, border = BorderStroke(1.dp, C.Border), modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(4.dp)) {
                perfis.forEach { (key, label) ->
                    val sel = perfil == key
                    Surface(
                        onClick = { perfil = key }, modifier = Modifier.weight(1f).height(40.dp),
                        shape = RoundedCornerShape(10.dp), color = if (sel) C.Primary else Color.Transparent
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, color = if (sel) Color.White else C.Title)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        AppField(email, { email = it }, "E-mail", placeholder = "seu@email.com", leading = Icons.Filled.Email, keyboard = KeyboardType.Email)
        Spacer(Modifier.height(14.dp))
        AppField(senha, { senha = it }, "Senha", placeholder = "Sua senha", leading = Icons.Filled.Lock, password = true)
        vm.error?.let { Text(it, color = C.RedFg, fontSize = 13.sp, modifier = Modifier.fillMaxWidth().padding(top = 10.dp)) }
        Spacer(Modifier.height(22.dp))
        AppButton("Entrar", { vm.entrar(email, senha, perfil) }, loading = vm.loading)
        if (perfil == "CLIENTE") TextButton(onClick = onRegister) { Text("Criar conta", color = C.Primary, fontWeight = FontWeight.Medium) }
        TextButton(onClick = { esqueci = true }) { Text("Esqueci minha senha", color = C.Muted, fontSize = 13.sp) }
    }

    if (esqueci) AlertDialog(
        onDismissRequest = { esqueci = false }, containerColor = Color.White,
        title = { Text("Recuperar senha", fontWeight = FontWeight.Bold, color = C.Title) },
        text = { Text("A recuperação automática de senha ainda não está disponível. Procure o administrador do estabelecimento para redefinir o seu acesso.") },
        confirmButton = { TextButton(onClick = { esqueci = false }) { Text("OK", color = C.Primary) } }
    )
}

@Composable
fun RegisterScreen(onBack: () -> Unit, vm: AuthVM = viewModel()) {
    var nome by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var telefone by rememberSaveable { mutableStateOf("") }
    var senha by rememberSaveable { mutableStateOf("") }
    var conf by rememberSaveable { mutableStateOf("") }

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = C.Title) }
        Text("Criar conta", fontFamily = Outfit, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = C.Text)
        Text("Cadastre-se para agendar seus serviços", color = C.Muted, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        AppField(nome, { nome = it }, "Nome completo", leading = Icons.Filled.Person)
        Spacer(Modifier.height(14.dp))
        AppField(email, { email = it }, "E-mail", leading = Icons.Filled.Email, keyboard = KeyboardType.Email)
        Spacer(Modifier.height(14.dp))
        AppField(telefone, { telefone = it }, "Telefone (opcional)", leading = Icons.Filled.Phone, keyboard = KeyboardType.Phone)
        Spacer(Modifier.height(14.dp))
        AppField(senha, { senha = it }, "Senha", placeholder = "Mínimo 6 caracteres", leading = Icons.Filled.Lock, password = true)
        Spacer(Modifier.height(14.dp))
        AppField(conf, { conf = it }, "Confirmar senha", leading = Icons.Filled.Lock, password = true)
        vm.error?.let { Text(it, color = C.RedFg, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
        Spacer(Modifier.height(22.dp))
        AppButton("Criar conta", { vm.cadastrar(nome, email, telefone, senha, conf) }, loading = vm.loading)
    }
}
