package br.com.agendafacil.app.ui.cliente

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.agendafacil.app.data.*
import br.com.agendafacil.app.ui.*
import kotlinx.coroutines.delay

class HomeVM : ViewModel() {
    val proximos = Resource(viewModelScope) { meusAgendamentos("proximos") }
}

val CATEGORIAS: List<Pair<String, ImageVector>> = listOf(
    "Cabelo" to Icons.Filled.ContentCut,
    "Estética" to Icons.Filled.AutoAwesome,
    "Consultoria" to Icons.Filled.Work,
    "Unhas" to Icons.Filled.Spa
)

fun iconeCategoria(cat: String): ImageVector = CATEGORIAS.firstOrNull { it.first.equals(cat, true) }?.second ?: Icons.Filled.ContentCut

@Composable
fun HomeTab(
    session: SessionData, onOpenProfile: () -> Unit, onVerTodos: () -> Unit,
    onCategoria: (String) -> Unit, onServico: (ServicoDto) -> Unit
) {
    val vm: HomeVM = userVm(session.usuario.id)
    LaunchedEffect(Unit) { vm.proximos.load() }
    var query by rememberSaveable { mutableStateOf("") }
    var resultados by remember { mutableStateOf<List<ServicoDto>?>(null) }
    var buscando by remember { mutableStateOf(false) }

    LaunchedEffect(query) {
        if (query.isBlank()) { resultados = null; buscando = false; return@LaunchedEffect }
        buscando = true
        delay(350)
        resultados = Api.call { servicos(query.trim(), null) }.getOrElse { Graph.toast(it.message ?: "Erro na busca"); emptyList() }
        buscando = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Olá, ${firstName(session.usuario.nome)}!", fontFamily = Outfit, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = C.Text)
                Text("Qual serviço você procura hoje?", fontSize = 13.sp, color = C.Muted)
            }
            Box(Modifier.clickable(onClick = onOpenProfile)) { Avatar(session.usuario.nome, 44.dp) }
        }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar serviços ou profissionais...", color = C.Muted, fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = C.Muted) },
            trailingIcon = { if (query.isNotEmpty()) IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, "Limpar", tint = C.Muted) } },
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                focusedBorderColor = C.Primary, unfocusedBorderColor = C.Border
            )
        )

        if (query.isNotBlank()) {
            SectionTitle("Resultados da busca")
            val r = resultados
            when {
                buscando && r == null -> CircularProgressIndicator(Modifier.padding(16.dp).size(24.dp), color = C.Primary, strokeWidth = 2.dp)
                r != null && r.isEmpty() -> EmptyState("Nenhum serviço encontrado para \"${query.trim()}\".")
                r != null -> Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { r.forEach { ServicoItem(it) { onServico(it) } } }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Próximos agendamentos", Modifier.weight(1f), fontFamily = Outfit, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = C.Text)
                Text("Ver todos", color = C.Primary, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onVerTodos))
            }
            ResourceView(vm.proximos) { lista ->
                if (lista.isEmpty()) EmptyState("Você ainda não tem agendamentos próximos.")
                else Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { lista.take(2).forEach { ProximoCard(it) } }
            }
            SectionTitle("Serviços populares")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CATEGORIAS.forEach { (nome, icon) ->
                    Surface(
                        onClick = { onCategoria(nome) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp),
                        color = Color.White, border = androidx.compose.foundation.BorderStroke(1.dp, C.Border)
                    ) {
                        Column(Modifier.padding(vertical = 14.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(40.dp).background(if (nome == "Estética") C.CoralBg else C.CyanBg, CircleShape), contentAlignment = Alignment.Center) {
                                Icon(icon, null, tint = if (nome == "Estética") C.Coral else C.Primary, modifier = Modifier.size(20.dp))
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(nome, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = C.Text, maxLines = 1, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun ServicoItem(s: ServicoDto, onClick: () -> Unit) {
    AppCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(C.CyanBg, CircleShape), contentAlignment = Alignment.Center) {
                Icon(iconeCategoria(s.categoria), null, tint = C.Primary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.nome, fontWeight = FontWeight.SemiBold, color = C.Text)
                Text("${s.categoria} • ${s.duracaoMinutos} min", fontSize = 12.sp, color = C.Muted)
            }
            Text(s.preco.brl(), fontWeight = FontWeight.Bold, color = C.Primary, fontSize = 14.sp)
        }
    }
}

@Composable
fun ProximoCard(a: AgendamentoDto) {
    val d = a.data.toDate()
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(
                Modifier.size(52.dp).background(if (a.status == "PENDENTE") C.CoralBg else C.CyanBg, RoundedCornerShape(12.dp)),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                val cor = if (a.status == "PENDENTE") C.Coral else C.Primary
                Text("${d.dayOfMonth}", fontWeight = FontWeight.Bold, color = cor, fontFamily = Outfit, fontSize = 16.sp)
                Text(d.mesCurto(), color = cor, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(a.servico, fontWeight = FontWeight.SemiBold, color = C.Text)
                Text("Profissional: ${a.profissional}", fontSize = 12.sp, color = C.Muted)
                Text("Horário: ${a.horaInicio}", fontSize = 12.sp, color = C.Muted)
            }
            StatusChip(a.status)
        }
    }
}
