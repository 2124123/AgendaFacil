package br.com.agendafacil.app.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

val PT_BR: Locale = Locale.forLanguageTag("pt-BR")
val ZONA: ZoneId = ZoneId.of("America/Sao_Paulo")

fun hoje(): LocalDate = LocalDate.now(ZONA)
fun String.toDate(): LocalDate = LocalDate.parse(this)
private fun String.cap() = replaceFirstChar { it.uppercase() }

fun LocalDate.fmtShort(): String = format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
fun LocalDate.fmtDiaMes(): String = format(DateTimeFormatter.ofPattern("dd/MM"))
fun LocalDate.mesNome(): String = month.getDisplayName(TextStyle.FULL, PT_BR).cap()
fun LocalDate.mesAno(): String = "${mesNome()} $year"
fun LocalDate.fmtLonga(): String = "$dayOfMonth de ${mesNome()}, $year"
fun LocalDate.mesCurto(): String = month.getDisplayName(TextStyle.SHORT, PT_BR).replace(".", "").uppercase().take(3)
fun LocalDate.diaSemanaCurto(): String =
    dayOfWeek.getDisplayName(TextStyle.SHORT, PT_BR).replace(".", "").cap().take(3)
fun LocalDate.diaSemanaLongo(): String = dayOfWeek.getDisplayName(TextStyle.FULL, PT_BR).cap()

fun Double.brl(): String = NumberFormat.getCurrencyInstance(PT_BR).format(this)
fun firstName(nome: String): String = nome.trim().substringBefore(' ')

/** "2min atrás", "1h atrás", "ontem", "dd/MM". */
fun tempoRelativo(iso: String): String = try {
    val t = LocalDateTime.parse(iso)
    val min = Duration.between(t, LocalDateTime.now(ZONA)).toMinutes()
    when {
        min < 1 -> "agora"
        min < 60 -> "${min}min atrás"
        min < 60 * 24 -> "${min / 60}h atrás"
        min < 60 * 48 -> "ontem"
        else -> t.toLocalDate().fmtDiaMes()
    }
} catch (e: Exception) {
    ""
}

fun perfilLabel(p: String) = when (p) {
    "PROFISSIONAL" -> "Profissional"
    "ADMINISTRADOR" -> "Administrador"
    else -> "Cliente"
}

/** ViewModel separado por usuário: evita misturar dados quando outra conta entra no mesmo aparelho. */
@Composable
inline fun <reified T : ViewModel> userVm(userId: Long): T =
    viewModel<T>(key = "${T::class.java.simpleName}-$userId")
