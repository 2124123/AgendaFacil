package br.com.agendafacil.app.data

import android.app.Application
import android.content.Context
import android.widget.Toast
import br.com.agendafacil.app.BuildConfig
import com.google.gson.Gson
import com.google.gson.JsonParser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.HttpException
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.io.IOException
import java.util.concurrent.TimeUnit

interface ApiService {
    // ---- autenticação / perfil
    @POST("api/auth/login") suspend fun login(@Body b: LoginReq): AuthRes
    @POST("api/auth/register") suspend fun registrar(@Body b: RegisterReq): AuthRes
    @PUT("api/me") suspend fun atualizarPerfil(@Body b: PerfilUpdate): UsuarioDto

    // ---- consultas (cliente)
    @GET("api/servicos") suspend fun servicos(@Query("busca") busca: String?, @Query("categoria") categoria: String?): List<ServicoDto>
    @GET("api/profissionais") suspend fun profissionais(@Query("servicoId") servicoId: Long?): List<ProfissionalDto>
    @GET("api/agenda/dias") suspend fun diasDisponiveis(
        @Query("profissionalId") profissionalId: Long, @Query("servicoId") servicoId: Long,
        @Query("inicio") inicio: String, @Query("dias") dias: Int
    ): List<DiaDisponivelDto>
    @GET("api/agenda/horarios") suspend fun horariosLivres(
        @Query("profissionalId") profissionalId: Long, @Query("servicoId") servicoId: Long,
        @Query("data") data: String, @Query("ignorarId") ignorarId: Long?
    ): List<String>

    // ---- agendamentos do cliente
    @POST("api/cliente/agendamentos") suspend fun criarAgendamento(@Body b: AgendamentoReq): AgendamentoDto
    @GET("api/cliente/agendamentos") suspend fun meusAgendamentos(@Query("tipo") tipo: String): List<AgendamentoDto>
    @PUT("api/cliente/agendamentos/{id}/remarcar") suspend fun remarcarCliente(@Path("id") id: Long, @Body b: RemarcarReq): AgendamentoDto
    @PATCH("api/cliente/agendamentos/{id}/cancelar") suspend fun cancelarCliente(@Path("id") id: Long): AgendamentoDto

    // ---- profissional
    @GET("api/profissional/agenda") suspend fun agendaProfissional(@Query("data") data: String, @Query("dias") dias: Int): AgendaDto
    @PATCH("api/profissional/agendamentos/{id}/confirmar") suspend fun confirmarAtendimento(@Path("id") id: Long): AgendamentoDto
    @PATCH("api/profissional/agendamentos/{id}/realizar") suspend fun realizarAtendimento(@Path("id") id: Long): AgendamentoDto
    @PATCH("api/profissional/agendamentos/{id}/cancelar") suspend fun cancelarProfissional(@Path("id") id: Long): AgendamentoDto
    @POST("api/profissional/bloqueios") suspend fun bloquear(@Body b: BloqueioReq): BloqueioDto
    @DELETE("api/profissional/bloqueios/{id}") suspend fun removerBloqueio(@Path("id") id: Long)
    @GET("api/profissional/clientes") suspend fun clientesAtendidos(): List<ClienteResumoDto>

    // ---- notificações
    @GET("api/notificacoes") suspend fun notificacoes(): List<NotificacaoDto>
    @PATCH("api/notificacoes/{id}/lida") suspend fun marcarLida(@Path("id") id: Long)
    @POST("api/notificacoes/lidas") suspend fun marcarTodasLidas()

    // ---- administrador
    @GET("api/admin/servicos") suspend fun adminServicos(@Query("busca") busca: String?): List<ServicoDto>
    @POST("api/admin/servicos") suspend fun adminCriarServico(@Body f: ServicoForm): ServicoDto
    @PUT("api/admin/servicos/{id}") suspend fun adminAtualizarServico(@Path("id") id: Long, @Body f: ServicoForm): ServicoDto
    @PATCH("api/admin/servicos/{id}/ativo") suspend fun adminAtivoServico(@Path("id") id: Long, @Query("valor") valor: Boolean): ServicoDto
    @GET("api/admin/profissionais") suspend fun adminProfissionais(): List<ProfissionalDto>
    @POST("api/admin/profissionais") suspend fun adminCriarProfissional(@Body f: ProfissionalForm): ProfissionalDto
    @PUT("api/admin/profissionais/{id}") suspend fun adminAtualizarProfissional(@Path("id") id: Long, @Body f: ProfissionalForm): ProfissionalDto
    @PATCH("api/admin/profissionais/{id}/ativo") suspend fun adminAtivoProfissional(@Path("id") id: Long, @Query("valor") valor: Boolean): ProfissionalDto
    @GET("api/admin/profissionais/{id}/disponibilidade") suspend fun adminDisponibilidade(@Path("id") id: Long): List<DisponibilidadeDto>
    @PUT("api/admin/profissionais/{id}/disponibilidade") suspend fun adminDefinirDisponibilidade(@Path("id") id: Long, @Body l: List<DisponibilidadeDto>): List<DisponibilidadeDto>
    @GET("api/admin/dashboard") suspend fun adminDashboard(): DashboardDto
    @GET("api/admin/relatorios/agendamentos") suspend fun adminRelatorio(@Query("inicio") inicio: String?, @Query("fim") fim: String?): RelatorioDto
}

/** Guarda o token JWT e o usuário logado (SharedPreferences privado do app). */
class Session(context: Context) {
    private val prefs = context.getSharedPreferences("agenda_session", Context.MODE_PRIVATE)
    private val gson = Gson()
    private val _state = MutableStateFlow(load())
    val state: StateFlow<SessionData?> = _state

    val token: String? get() = _state.value?.token

    private fun load(): SessionData? = try {
        prefs.getString("session", null)?.let { gson.fromJson(it, SessionData::class.java) }
    } catch (e: Exception) {
        null
    }

    private fun persist(data: SessionData?) {
        prefs.edit().apply { if (data == null) remove("session") else putString("session", gson.toJson(data)) }.apply()
        _state.value = data
    }

    fun save(res: AuthRes) = persist(SessionData(res.token, res.usuario, res.estabelecimento ?: "Agenda Fácil"))
    fun updateUser(u: UsuarioDto) {
        _state.value?.let { persist(it.copy(usuario = u)) }
    }
    fun clear() = persist(null)
}

object Graph {
    lateinit var app: Application
        private set
    lateinit var session: Session
        private set

    val api: ApiService by lazy {
        val client = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .addInterceptor { chain ->
                val req = chain.request().newBuilder().apply {
                    session.token?.let { header("Authorization", "Bearer $it") }
                }.build()
                val res = chain.proceed(req)
                // Token expirado/inválido fora das telas de login: volta para o login.
                if (res.code == 401 && !req.url.encodedPath.startsWith("/api/auth")) session.clear()
                res
            }
            .addInterceptor(HttpLoggingInterceptor().apply {
                level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC else HttpLoggingInterceptor.Level.NONE
            })
            .build()
        Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    fun init(application: Application) {
        app = application
        session = Session(application)
    }

    fun toast(msg: String) = Toast.makeText(app, msg, Toast.LENGTH_LONG).show()
}

class ApiError(message: String) : Exception(message)

object Api {
    suspend fun <T> call(block: suspend ApiService.() -> T): Result<T> = try {
        Result.success(Graph.api.block())
    } catch (e: CancellationException) {
        throw e
    } catch (e: HttpException) {
        Result.failure(ApiError(httpMessage(e)))
    } catch (e: IOException) {
        Result.failure(ApiError("Sem conexão com o servidor. Verifique a internet e o endereço da API."))
    } catch (e: Exception) {
        Result.failure(ApiError(e.message ?: "Erro inesperado"))
    }

    private fun httpMessage(e: HttpException): String {
        val body = try { e.response()?.errorBody()?.string() } catch (x: Exception) { null }
        val msg = try { JsonParser.parseString(body).asJsonObject.get("message")?.asString } catch (x: Exception) { null }
        return msg ?: when (e.code()) {
            401 -> "Sessão expirada. Entre novamente."
            403 -> "Você não tem permissão para esta ação."
            404 -> "Registro não encontrado."
            else -> "Erro ${e.code()} no servidor."
        }
    }
}

/** Estado de uma tela que carrega dados do servidor. */
sealed interface Ui<out T> {
    data object Loading : Ui<Nothing>
    data class Error(val message: String) : Ui<Nothing>
    data class Data<T>(val value: T) : Ui<T>
}

class Resource<T>(private val scope: CoroutineScope, private val fetch: suspend ApiService.() -> T) {
    private val _state = MutableStateFlow<Ui<T>>(Ui.Loading)
    val state: StateFlow<Ui<T>> = _state
    private val _refreshing = MutableStateFlow(false)
    val refreshing: StateFlow<Boolean> = _refreshing

    fun load() {
        scope.launch {
            if (_state.value !is Ui.Data) _state.value = Ui.Loading
            _refreshing.value = true
            Api.call(fetch).fold(
                onSuccess = { _state.value = Ui.Data(it) },
                onFailure = {
                    if (_state.value is Ui.Data) Graph.toast(it.message ?: "Erro ao atualizar")
                    else _state.value = Ui.Error(it.message ?: "Erro ao carregar")
                }
            )
            _refreshing.value = false
        }
    }

    fun reset() {
        _state.value = Ui.Loading
    }

    val dataOrNull: T? get() = (_state.value as? Ui.Data<T>)?.value
}
