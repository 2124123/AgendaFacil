package br.com.agendafacil.app.ui.profissional

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.agendafacil.app.data.*
import br.com.agendafacil.app.ui.*
import br.com.agendafacil.app.ui.common.NotifVM
import br.com.agendafacil.app.ui.common.NotificacoesScreen
import br.com.agendafacil.app.ui.common.ProfileScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate

class AgendaVM : ViewModel() {
    var data by mutableStateOf(hoje())
    var semana by mutableStateOf(false)
    var working by mutableStateOf(false)
    val agenda = Resource(viewModelScope) { agendaProfissional(data.toString(), if (semana) 7 else 1) }
    val clientes = Resource(viewModelScope) { clientesAtendidos() }

    fun mudarData(d: LocalDate) { data = d; agenda.load() }
    fun alternarSemana() { semana = !semana; agenda.reset(); agenda.load() }

    private fun acao(msg: String, chamada: suspend ApiService.() -> AgendamentoDto, onOk: () -> Unit = {}) {
        viewModelScope.launch {
            working = true
            Api.call(chamada).fold({ Graph.toast(msg); onOk(); agenda.load() }, { Graph.toast(it.message ?: "Erro") })
            working = false
        }
    }

    fun confirmar(a: AgendamentoDto, onOk: () -> Unit) = acao("Agendamento confirmado", { confirmarAtendimento(a.id) }, onOk)
    fun realizar(a: AgendamentoDto, onOk: () -> Unit) = acao("Atendimento registrado como realizado", { realizarAtendimento(a.id) }, onOk)
    fun cancelar(a: AgendamentoDto, onOk: () -> Unit) = acao("Atendimento cancelado", { cancelarProfissional(a.id) }, onOk)

    fun criarBloqueio(req: BloqueioReq, onOk: () -> Unit) {
        viewModelScope.launch {
            working = true
            Api.call { bloquear(req) }.fold({ Graph.toast("Horário bloqueado"); onOk(); agenda.load() }, { Graph.toast(it.message ?: "Erro ao bloquear") })
            working = false
        }
    }

    fun excluirBloqueio(b: BloqueioDto) {
        viewModelScope.launch {
            Api.call { removerBloqueio(b.id) }.fold({ Graph.toast("Bloqueio removido"); agenda.load() }, { Graph.toast(it.message ?: "Erro") })
        }
    }
}

@Composable
fun ProfissionalShell(session: SessionData) {
    val uid = session.usuario.id
    val notif: NotifVM = userVm(uid)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { notif.lista.load(); delay(30_000) } }
    val estado by notif.lista.state.collectAsState()
    val naoLidas = (estado as? Ui.Data<List<NotificacaoDto>>)?.value?.count { !it.lida } ?: 0

    val items = listOf(
        NavItem("Agenda", Icons.Filled.CalendarMonth), NavItem("Clientes", Icons.Filled.Groups),
        NavItem("Notificações", Icons.Filled.Notifications, naoLidas), NavItem("Perfil", Icons.Filled.Person)
    )
    BackHandler(enabled = tab != 0) { tab = 0 }
    Scaffold(containerColor = C.Bg, bottomBar = { AppBottomBar(items, tab) { tab = it } }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when (tab) {
                0 -> AgendaTab(session)
                1 -> ClientesTab(session)
                2 -> NotificacoesScreen(notif)
                else -> ProfileScreen(session)
            }
        }
    }
}

private sealed class Entrada(val data: String, val hora: String) {
    class Ag(val a: AgendamentoDto) : Entrada(a.data, a.horaInicio)
    class Blq(val b: BloqueioDto) : Entrada(b.data, b.horaInicio)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgendaTab(session: SessionData) {
    val vm: AgendaVM = userVm(session.usuario.id)
    LaunchedEffect(Unit) { vm.agenda.load() }
    val refreshing by vm.agenda.refreshing.collectAsState()
    var selecionado by remember { mutableStateOf<AgendamentoDto?>(null) }
    var bloqueando by remember { mutableStateOf(false) }

    val d = vm.data
    val rotulo = if (d == hoje()) "Hoje: ${d.diaSemanaLongo()}, ${d.dayOfMonth} ${d.mesCurto().lowercase().replaceFirstChar { it.uppercase() }}"
    else "${d.diaSemanaLongo()}, ${d.fmtShort()}"

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Agenda de ${firstName(session.usuario.nome)}", fontFamily = Outfit, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = C.Text)
                Text(rotulo, fontSize = 13.sp, color = C.Muted)
            }
            Avatar(session.usuario.nome, 44.dp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppButton("Bloquear Horário", { bloqueando = true }, Modifier.weight(1f), kind = BtnKind.Outline)
            AppButton(if (vm.semana) "Ver Dia" else "Ver Semana", { vm.alternarSemana() }, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (vm.semana) "Próximos 7 dias" else "Horários do dia", Modifier.weight(1f), fontFamily = Outfit, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = C.Text)
            IconButton(onClick = { vm.mudarData(vm.data.minusDays(if (vm.semana) 7 else 1)) }) { Icon(Icons.Filled.ChevronLeft, "Anterior", tint = C.Title) }
            IconButton(onClick = { vm.mudarData(vm.data.plusDays(if (vm.semana) 7 else 1)) }) { Icon(Icons.Filled.ChevronRight, "Próximo", tint = C.Title) }
        }
        PullToRefreshBox(isRefreshing = refreshing, onRefresh = { vm.agenda.load() }, modifier = Modifier.weight(1f)) {
            ResourceView(vm.agenda) { ag ->
                val entradas = (ag.agendamentos.map { Entrada.Ag(it) } + ag.bloqueios.map { Entrada.Blq(it) })
                    .sortedWith(compareBy({ it.data }, { it.hora }))
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (entradas.isEmpty()) EmptyState("Nenhum atendimento neste período.")
                    var ultimoDia = ""
                    entradas.forEach { e ->
                        if (vm.semana && e.data != ultimoDia) {
                            ultimoDia = e.data
                            val dia = e.data.toDate()
                            Text("${dia.diaSemanaLongo()}, ${dia.fmtDiaMes()}", fontWeight = FontWeight.Bold, color = C.Title, modifier = Modifier.padding(top = 8.dp))
                        }
                        Row(verticalAlignment = Alignment.Top) {
                            Text(e.hora, Modifier.width(56.dp).padding(top = 14.dp), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = C.Text)
                            when (e) {
                                is Entrada.Ag -> AppCard(Modifier.weight(1f), onClick = { selecionado = e.a }) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(e.a.servico, Modifier.weight(1f), fontWeight = FontWeight.Bold, color = C.Text)
                                        StatusChip(e.a.status)
                                    }
                                    Text("Cliente: ${e.a.cliente}", fontSize = 13.sp, color = C.Muted, modifier = Modifier.padding(top = 4.dp))
                                }
                                is Entrada.Blq -> Surface(Modifier.weight(1f), shape = RoundedCornerShape(16.dp), color = C.Border) {
                                    Row(Modifier.padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text("Bloqueado até ${e.b.horaFim}", fontWeight = FontWeight.SemiBold, color = C.Title)
                                            if (!e.b.motivo.isNullOrBlank()) Text(e.b.motivo, fontSize = 12.sp, color = C.Muted)
                                        }
                                        IconButton(onClick = { vm.excluirBloqueio(e.b) }) { Icon(Icons.Filled.Close, "Remover bloqueio", tint = C.Muted) }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }

    selecionado?.let { a -> AcoesDialog(a, vm) { selecionado = null } }
    if (bloqueando) BloqueioDialog(vm) { bloqueando = false }
}

@Composable
private fun AcoesDialog(a: AgendamentoDto, vm: AgendaVM, onClose: () -> Unit) {
    var cancelar by remember { mutableStateOf(false) }
    AppDialog(a.servico, onClose) {
        StatusChip(a.status)
        Spacer(Modifier.height(12.dp))
        Text("Cliente: ${a.cliente}", color = C.Text)
        if (!a.clienteTelefone.isNullOrBlank()) Text("Telefone: ${a.clienteTelefone}", color = C.Muted, fontSize = 13.sp)
        Text("${a.data.toDate().fmtShort()} • ${a.horaInicio} às ${a.horaFim}", color = C.Muted, fontSize = 13.sp)
        Text("Valor: ${a.valor.brl()}", color = C.Primary, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
        Spacer(Modifier.height(16.dp))
        if (a.status == "PENDENTE") AppButton("Confirmar agendamento", { vm.confirmar(a, onClose) }, loading = vm.working)
        if (a.status == "CONFIRMADO" && !a.data.toDate().isAfter(hoje())) {
            AppButton("Registrar como realizado", { vm.realizar(a, onClose) }, loading = vm.working)
        }
        if (a.status == "PENDENTE" || a.status == "CONFIRMADO") {
            Spacer(Modifier.height(10.dp))
            AppButton("Cancelar atendimento", { cancelar = true }, kind = BtnKind.Danger)
        }
        Spacer(Modifier.height(10.dp))
        AppButton("Fechar", onClose, kind = BtnKind.Soft)
    }
    if (cancelar) ConfirmDialog("Cancelar atendimento", "O cliente ${a.cliente} será notificado. Continuar?", "Cancelar atendimento",
        { cancelar = false; vm.cancelar(a, onClose) }, { cancelar = false })
}

@Composable
private fun BloqueioDialog(vm: AgendaVM, onClose: () -> Unit) {
    var data by remember { mutableStateOf(vm.data.let { if (it.isBefore(hoje())) hoje() else it }) }
    var ini by remember { mutableStateOf("12:00") }
    var fim by remember { mutableStateOf("13:00") }
    var motivo by remember { mutableStateOf("") }
    AppDialog("Bloquear horário", onClose) {
        DateField("Data", data, { data = it })
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            DropdownField("Início", ini, HORARIOS_PADRAO, { ini = it }, Modifier.weight(1f))
            DropdownField("Fim", fim, HORARIOS_PADRAO, { fim = it }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        AppField(motivo, { motivo = it }, "Motivo (opcional)")
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppButton("Voltar", onClose, Modifier.weight(1f), kind = BtnKind.Soft)
            AppButton("Bloquear", {
                if (fim <= ini) Graph.toast("O horário final deve ser depois do inicial")
                else vm.criarBloqueio(BloqueioReq(data.toString(), ini, fim, motivo.trim().ifBlank { null }), onClose)
            }, Modifier.weight(1f), loading = vm.working)
        }
    }
}

@Composable
fun ClientesTab(session: SessionData) {
    val vm: AgendaVM = userVm(session.usuario.id)
    LaunchedEffect(Unit) { vm.clientes.load() }
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenTitle("Clientes", "Clientes com atendimentos na sua agenda")
        ResourceView(vm.clientes) { lista ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (lista.isEmpty()) EmptyState("Você ainda não possui clientes.")
                lista.forEach { c ->
                    AppCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(c.nome, 46.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(c.nome, fontWeight = FontWeight.Bold, color = C.Text)
                                Text(c.telefone ?: c.email, fontSize = 12.sp, color = C.Muted)
                                Text(
                                    c.ultimoAtendimento?.let { "Último atendimento: ${it.toDate().fmtShort()}" } ?: "Sem atendimento realizado",
                                    fontSize = 12.sp, color = C.Muted
                                )
                            }
                            Pill("${c.atendimentos} agend.", C.CyanBg, C.Primary)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}
