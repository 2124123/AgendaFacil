package br.com.agendafacil.app.ui.cliente

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.agendafacil.app.data.*
import br.com.agendafacil.app.ui.*
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

/** Fluxo de agendamento em 4 etapas: 1 Serviço, 2 Profissional, 3 Data/Hora, 4 Confirmação. */
class BookingVM : ViewModel() {
    var step by mutableIntStateOf(1)
    var categoria by mutableStateOf<String?>(null)
    var servico by mutableStateOf<ServicoDto?>(null)
    var profissional by mutableStateOf<ProfissionalDto?>(null)
    var data by mutableStateOf<LocalDate?>(null)
    var hora by mutableStateOf<String?>(null)
    var resultado by mutableStateOf<AgendamentoDto?>(null)
    var saving by mutableStateOf(false)
    var slotsVersion by mutableIntStateOf(0)

    val servicos = Resource(viewModelScope) { servicos(null, categoria) }
    val profissionais = Resource(viewModelScope) { profissionais(servico?.id) }

    fun iniciarPorCategoria(cat: String) {
        limparEscolhas(); categoria = cat; step = 1
    }

    fun iniciarComServico(s: ServicoDto) {
        limparEscolhas(); categoria = null; selecionarServico(s)
    }

    private fun limparEscolhas() {
        servico = null; profissional = null; data = null; hora = null; resultado = null
    }

    fun selecionarServico(s: ServicoDto) {
        servico = s; profissional = null; data = null; hora = null; step = 2
    }

    fun selecionarProfissional(p: ProfissionalDto) {
        profissional = p; data = null; hora = null; step = 3
    }

    fun voltar() {
        when (step) {
            3 -> { data = null; hora = null; step = 2 }
            2 -> { profissional = null; step = 1 }
        }
    }

    fun reset() {
        limparEscolhas(); categoria = null; step = 1
    }

    fun confirmar() {
        val s = servico ?: return
        val p = profissional ?: return
        val d = data ?: return
        val h = hora ?: return
        viewModelScope.launch {
            saving = true
            Api.call { criarAgendamento(AgendamentoReq(p.id, s.id, d.toString(), h)) }.fold(
                onSuccess = { resultado = it; step = 4 },
                onFailure = { Graph.toast(it.message ?: "Não foi possível agendar"); hora = null; slotsVersion++ }
            )
            saving = false
        }
    }
}

@Composable
fun BookingTab(vm: BookingVM, onGoMeus: () -> Unit) {
    val ok = vm.resultado
    if (ok != null) {
        ConfirmacaoScreen(ok, onMeus = { vm.reset(); onGoMeus() })
        return
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (vm.step > 1) IconButton(onClick = { vm.voltar() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = C.Title) }
            else Spacer(Modifier.width(8.dp))
            Text("Novo Agendamento", fontFamily = Outfit, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Text)
        }
        Stepper(vm.step, Modifier.padding(horizontal = 20.dp))
        Row(Modifier.padding(horizontal = 20.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            vm.servico?.let { InfoChip(it.nome, Icons.Filled.ContentCut) }
            vm.profissional?.let { InfoChip(it.nome, Icons.Filled.Person) }
        }
        Box(Modifier.weight(1f)) {
            when (vm.step) {
                1 -> StepServico(vm)
                2 -> StepProfissional(vm)
                else -> StepDataHora(vm)
            }
        }
    }
}

@Composable
private fun Stepper(atual: Int, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        (1..4).forEach { n ->
            val (bg, fg) = when {
                n < atual -> C.Primary to Color.White
                n == atual -> C.Coral to Color.White
                else -> Color.White to C.Muted
            }
            Box(
                Modifier.size(24.dp).background(bg, CircleShape).border(1.dp, if (n > atual) C.Border else bg, CircleShape),
                contentAlignment = Alignment.Center
            ) { Text("$n", color = fg, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            if (n < 4) Box(Modifier.width(24.dp).height(2.dp).background(if (n < atual) C.Primary else C.Border))
        }
    }
}

@Composable
private fun InfoChip(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        Modifier.background(Color.White, RoundedCornerShape(50)).padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = C.Primary, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = C.Title)
    }
}

@Composable
private fun StepServico(vm: BookingVM) {
    LaunchedEffect(vm.categoria) { vm.servicos.load() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Text("Escolha o serviço", fontWeight = FontWeight.Bold, fontFamily = Outfit, fontSize = 16.sp, color = C.Text)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = vm.categoria == null, onClick = { vm.categoria = null }, label = { Text("Todos") })
            CATEGORIAS.forEach { (nome, _) ->
                FilterChip(selected = vm.categoria == nome, onClick = { vm.categoria = nome }, label = { Text(nome) })
            }
        }
        Spacer(Modifier.height(12.dp))
        ResourceView(vm.servicos) { lista ->
            if (lista.isEmpty()) EmptyState("Nenhum serviço disponível nesta categoria.")
            else Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { lista.forEach { s -> ServicoItem(s) { vm.selecionarServico(s) } } }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StepProfissional(vm: BookingVM) {
    LaunchedEffect(vm.servico?.id) { vm.profissionais.reset(); vm.profissionais.load() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Text("Escolha o profissional", fontWeight = FontWeight.Bold, fontFamily = Outfit, fontSize = 16.sp, color = C.Text)
        Spacer(Modifier.height(10.dp))
        ResourceView(vm.profissionais) { lista ->
            if (lista.isEmpty()) EmptyState("Nenhum profissional disponível para este serviço.")
            else Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                lista.forEach { p ->
                    AppCard(onClick = { vm.selecionarProfissional(p) }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p.nome, 48.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.nome, fontWeight = FontWeight.SemiBold, color = C.Text)
                                Text(p.especialidade, fontSize = 12.sp, color = C.Muted)
                            }
                            Icon(Icons.Filled.ChevronRight, null, tint = C.Muted)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StepDataHora(vm: BookingVM) {
    val s = vm.servico
    val p = vm.profissional
    if (s == null || p == null) return
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
            SlotPicker(p.id, s.id, null, vm.data, vm.hora, vm.slotsVersion, { vm.data = it }, { vm.hora = it })
            Spacer(Modifier.height(16.dp))
        }
        Surface(color = Color.White, shadowElevation = 8.dp) {
            Box(Modifier.padding(20.dp)) {
                AppButton("Continuar", { vm.confirmar() }, enabled = vm.data != null && vm.hora != null, loading = vm.saving)
            }
        }
    }
}

/** Calendário de 7 dias + horários livres. Dias sem vaga ficam desabilitados (RN002). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SlotPicker(
    profissionalId: Long, servicoId: Long, ignorarId: Long?,
    date: LocalDate?, time: String?, refreshKey: Int,
    onDate: (LocalDate) -> Unit, onTime: (String?) -> Unit
) {
    var inicio by remember { mutableStateOf(hoje()) }
    var dias by remember { mutableStateOf<List<DiaDisponivelDto>?>(null) }
    var horarios by remember { mutableStateOf<List<String>?>(null) }

    LaunchedEffect(inicio, profissionalId, servicoId, refreshKey) {
        dias = null
        dias = Api.call { diasDisponiveis(profissionalId, servicoId, inicio.toString(), 7) }
            .getOrElse { Graph.toast(it.message ?: "Erro ao carregar datas"); emptyList() }
    }
    LaunchedEffect(date, profissionalId, servicoId, refreshKey) {
        horarios = null
        if (date != null) {
            horarios = Api.call { horariosLivres(profissionalId, servicoId, date.toString(), ignorarId) }
                .getOrElse { Graph.toast(it.message ?: "Erro ao carregar horários"); emptyList() }
        }
    }

    Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(inicio.mesAno(), Modifier.weight(1f), fontWeight = FontWeight.Bold, color = C.Text)
        IconButton(onClick = { inicio = inicio.minusDays(7) }, enabled = inicio.isAfter(hoje())) {
            Icon(Icons.Filled.ChevronLeft, "Semana anterior", tint = C.Title)
        }
        IconButton(onClick = { inicio = inicio.plusDays(7) }) { Icon(Icons.Filled.ChevronRight, "Próxima semana", tint = C.Title) }
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        (0..6).map { inicio.plusDays(it.toLong()) }.forEach { d ->
            val livre = dias?.firstOrNull { it.data == d.toString() }?.let { it.horarios > 0 } == true
            val sel = d == date
            Surface(
                onClick = { onDate(d); onTime(null) }, enabled = livre, modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp), color = if (sel) C.Primary else Color.White,
                border = if (sel) null else BorderStroke(1.dp, C.Border)
            ) {
                Column(Modifier.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(d.diaSemanaCurto(), fontSize = 11.sp, color = if (sel) Color.White else if (livre) C.Muted else C.Border)
                    Text("${d.dayOfMonth}", fontFamily = Outfit, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else if (livre) C.Text else C.Border)
                }
            }
        }
    }
    Text("Horários disponíveis", fontWeight = FontWeight.Bold, color = C.Text, modifier = Modifier.padding(top = 20.dp, bottom = 10.dp))
    val h = horarios
    when {
        date == null -> Text("Selecione uma data acima.", color = C.Muted, fontSize = 13.sp)
        h == null -> CircularProgressIndicator(Modifier.size(24.dp), color = C.Primary, strokeWidth = 2.dp)
        h.isEmpty() -> Text("Sem horários disponíveis nesta data.", color = C.Muted, fontSize = 13.sp)
        else -> FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            h.forEach { hora ->
                val sel = hora == time
                Surface(
                    onClick = { onTime(hora) }, shape = RoundedCornerShape(12.dp),
                    color = if (sel) C.Coral else Color.White, border = if (sel) null else BorderStroke(1.dp, C.Border)
                ) {
                    Text(hora, Modifier.padding(horizontal = 18.dp, vertical = 12.dp), color = if (sel) Color.White else C.Text, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun ConfirmacaoScreen(a: AgendamentoDto, onMeus: () -> Unit) {
    val ctx = LocalContext.current
    val data = a.data.toDate()
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(32.dp))
        Box(Modifier.size(72.dp).background(C.GreenBg, CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Check, null, tint = C.GreenFg, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(
            if (a.status == "CONFIRMADO") "Agendamento Confirmado!" else "Agendamento Solicitado!",
            fontFamily = Outfit, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = C.Title, textAlign = TextAlign.Center
        )
        if (a.status != "CONFIRMADO") Text("Aguardando a confirmação do profissional.", color = C.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        AppCard {
            Text("SERVIÇO", fontSize = 11.sp, color = C.Muted, fontWeight = FontWeight.Medium)
            Text(a.servico, fontFamily = Outfit, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = C.Text)
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = C.Border)
            LinhaInfo("Profissional", a.profissional)
            LinhaInfo("Data", data.fmtShort())
            LinhaInfo("Horário", a.horaInicio)
            Text("Local", fontSize = 14.sp, color = C.Muted, modifier = Modifier.padding(top = 6.dp))
            Text(a.local ?: "", fontWeight = FontWeight.Bold, color = C.Text)
            if (!a.endereco.isNullOrBlank()) Text(a.endereco, fontSize = 12.sp, color = C.Muted)
            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = C.Border)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Valor", Modifier.weight(1f), fontWeight = FontWeight.Bold, color = C.Text)
                Text(a.valor.brl(), fontFamily = Outfit, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Primary)
            }
        }
        Spacer(Modifier.height(24.dp))
        AppButton("Adicionar ao Calendário", { adicionarAoCalendario(ctx, a) }, kind = BtnKind.Outline)
        Spacer(Modifier.height(12.dp))
        AppButton("Ver Meus Agendamentos", onMeus)
    }
}

@Composable
private fun LinhaInfo(rotulo: String, valor: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Text(rotulo, Modifier.weight(1f), fontSize = 14.sp, color = C.Muted)
        Text(valor, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = C.Text)
    }
}

private fun adicionarAoCalendario(ctx: Context, a: AgendamentoDto) {
    val d = a.data.toDate()
    val ini = LocalDateTime.of(d, LocalTime.parse(a.horaInicio)).atZone(ZONA).toInstant().toEpochMilli()
    val fim = LocalDateTime.of(d, LocalTime.parse(a.horaFim)).atZone(ZONA).toInstant().toEpochMilli()
    val intent = Intent(Intent.ACTION_INSERT).apply {
        data = CalendarContract.Events.CONTENT_URI
        putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, ini)
        putExtra(CalendarContract.EXTRA_EVENT_END_TIME, fim)
        putExtra(CalendarContract.Events.TITLE, "${a.servico} - ${a.local ?: "Agenda Fácil"}")
        putExtra(CalendarContract.Events.DESCRIPTION, "Profissional: ${a.profissional}")
        putExtra(CalendarContract.Events.EVENT_LOCATION, a.endereco ?: "")
    }
    try {
        ctx.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Graph.toast("Nenhum aplicativo de calendário encontrado")
    }
}
