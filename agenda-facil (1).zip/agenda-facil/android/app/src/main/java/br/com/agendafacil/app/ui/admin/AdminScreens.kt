package br.com.agendafacil.app.ui.admin

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.agendafacil.app.data.*
import br.com.agendafacil.app.ui.*
import br.com.agendafacil.app.ui.cliente.CATEGORIAS
import br.com.agendafacil.app.ui.common.NotifVM
import br.com.agendafacil.app.ui.common.NotificacoesScreen
import br.com.agendafacil.app.ui.common.ProfileScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AdminVM : ViewModel() {
    var busca by mutableStateOf("")
    var periodo by mutableStateOf("mes")
    var working by mutableStateOf(false)

    val dashboard = Resource(viewModelScope) { adminDashboard() }
    val servicos = Resource(viewModelScope) { adminServicos(busca.trim().ifBlank { null }) }
    val equipe = Resource(viewModelScope) { adminProfissionais() }
    val relatorio = Resource(viewModelScope) {
        val fim = hoje()
        val ini = when (periodo) {
            "hoje" -> fim
            "7" -> fim.minusDays(6)
            "30" -> fim.minusDays(29)
            else -> fim.withDayOfMonth(1)
        }
        adminRelatorio(ini.toString(), fim.toString())
    }

    fun trocarPeriodo(p: String) { periodo = p; relatorio.reset(); relatorio.load() }

    private fun <T> executar(msg: String, onOk: () -> Unit, recarregar: () -> Unit, chamada: suspend ApiService.() -> T) {
        viewModelScope.launch {
            working = true
            Api.call(chamada).fold({ Graph.toast(msg); onOk(); recarregar() }, { Graph.toast(it.message ?: "Erro") })
            working = false
        }
    }

    fun gravarServico(id: Long?, f: ServicoForm, onOk: () -> Unit) =
        executar(if (id == null) "Serviço criado" else "Serviço atualizado", onOk, { servicos.load() }) {
            if (id == null) adminCriarServico(f) else adminAtualizarServico(id, f)
        }

    fun ativarServico(s: ServicoDto, ativo: Boolean) =
        executar(if (ativo) "Serviço ativado" else "Serviço desativado", {}, { servicos.load() }) { adminAtivoServico(s.id, ativo) }

    fun gravarProfissional(id: Long?, f: ProfissionalForm, onOk: () -> Unit) =
        executar(if (id == null) "Profissional cadastrado" else "Profissional atualizado", onOk, { equipe.load() }) {
            if (id == null) adminCriarProfissional(f) else adminAtualizarProfissional(id, f)
        }

    fun ativarProfissional(p: ProfissionalDto, ativo: Boolean) =
        executar(if (ativo) "Profissional ativado" else "Profissional desativado", {}, { equipe.load() }) { adminAtivoProfissional(p.id, ativo) }

    fun gravarHorarios(id: Long, lista: List<DisponibilidadeDto>, onOk: () -> Unit) =
        executar("Horários salvos", onOk, {}) { adminDefinirDisponibilidade(id, lista) }
}

@Composable
fun AdminShell(session: SessionData) {
    val uid = session.usuario.id
    val notif: NotifVM = userVm(uid)
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var relatorios by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { notif.lista.load(); delay(30_000) } }
    val estado by notif.lista.state.collectAsState()
    val naoLidas = (estado as? Ui.Data<List<NotificacaoDto>>)?.value?.count { !it.lida } ?: 0

    val items = listOf(
        NavItem("Painel", Icons.Filled.Dashboard), NavItem("Serviços", Icons.Filled.ContentCut),
        NavItem("Equipe", Icons.Filled.Groups), NavItem("Avisos", Icons.Filled.Notifications, naoLidas),
        NavItem("Perfil", Icons.Filled.Person)
    )
    BackHandler(enabled = relatorios || tab != 0) { if (relatorios) relatorios = false else tab = 0 }

    Scaffold(containerColor = C.Bg, bottomBar = { if (!relatorios) AppBottomBar(items, tab) { tab = it } }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            if (relatorios) RelatoriosScreen(uid) { relatorios = false }
            else when (tab) {
                0 -> PainelTab(uid, onServicos = { tab = 1 }, onEquipe = { tab = 2 }, onRelatorios = { relatorios = true })
                1 -> ServicosTab(uid)
                2 -> EquipeTab(uid)
                3 -> NotificacoesScreen(notif)
                else -> ProfileScreen(session)
            }
        }
    }
}

// ------------------------------------------------------------------ Painel

@Composable
fun PainelTab(uid: Long, onServicos: () -> Unit, onEquipe: () -> Unit, onRelatorios: () -> Unit) {
    val vm: AdminVM = userVm(uid)
    LaunchedEffect(Unit) { vm.dashboard.load() }
    val h = hoje()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        val nome = vm.dashboard.dataOrNull?.estabelecimento ?: "Painel"
        ScreenTitle(nome, "Hoje: ${h.diaSemanaLongo().substringBefore('-')}, ${h.dayOfMonth} ${h.mesCurto().lowercase().replaceFirstChar { it.uppercase() }}") {
            Pill("ADMIN", C.CyanBg, C.Primary)
        }
        ResourceView(vm.dashboard) { d ->
            SectionTitle("Resumo do Dia", Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AppCard(Modifier.weight(1f)) {
                    Text("Agendamentos Hoje", fontSize = 12.sp, color = C.Muted)
                    Text("${d.agendamentosHoje}", fontFamily = Outfit, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = C.Primary)
                    val v = d.variacaoPercentual
                    Text(
                        if (v == null) "Sem dados de ontem" else "${if (v >= 0) "+" else ""}$v% vs ontem",
                        fontSize = 12.sp, color = if (v == null) C.Muted else if (v >= 0) C.GreenFg else C.RedFg
                    )
                }
                AppCard(Modifier.weight(1f)) {
                    Text("Taxa de Ocupação", fontSize = 12.sp, color = C.Muted)
                    Text("${d.taxaOcupacao}%", fontFamily = Outfit, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = C.Primary)
                    Text(if (d.taxaOcupacao >= 70) "Bom desempenho" else "Pode melhorar", fontSize = 12.sp, color = if (d.taxaOcupacao >= 70) C.GreenFg else C.AmberFg)
                }
            }
            SectionTitle("Agendamentos na semana")
            AppCard {
                val max = (d.semana.maxOrNull() ?: 0).coerceAtLeast(1)
                val rotulos = listOf("S", "T", "Q", "Q", "S", "S", "D")
                Row(Modifier.fillMaxWidth().height(130.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                    d.semana.forEachIndexed { i, v ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                            Text("$v", fontSize = 10.sp, color = C.Muted)
                            Box(
                                Modifier.width(24.dp).height((v * 80f / max).coerceAtLeast(4f).dp)
                                    .background(if (v == max && v > 0) C.Coral else C.Primary, RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                            )
                            Spacer(Modifier.height(4.dp))
                            Text(rotulos[i], fontSize = 11.sp, color = C.Muted)
                        }
                    }
                }
            }
            SectionTitle("Profissionais Ativos")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (d.profissionais.isEmpty()) EmptyState("Nenhum profissional ativo.")
                d.profissionais.forEach { p ->
                    AppCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p.nome, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.nome, fontWeight = FontWeight.SemiBold, color = C.Text)
                                Text(p.especialidade, fontSize = 12.sp, color = C.Muted)
                            }
                            Pill("${p.agendamentosHoje} agend.", C.CyanBg, C.Primary)
                        }
                    }
                }
            }
            SectionTitle("Ações Rápidas")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AcaoRapida("Gerenciar Serviços", Icons.Filled.ContentCut, onServicos)
                AcaoRapida("Gerenciar Profissionais", Icons.Filled.Groups, onEquipe)
                AcaoRapida("Relatórios de Desempenho", Icons.Filled.Work, onRelatorios)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun AcaoRapida(texto: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    AppCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = C.Primary)
            Spacer(Modifier.width(12.dp))
            Text(texto, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, color = C.Text)
            Icon(Icons.Filled.ChevronRight, null, tint = C.Muted)
        }
    }
}

// ------------------------------------------------------------------ Serviços (RN005)

@Composable
fun ServicosTab(uid: Long) {
    val vm: AdminVM = userVm(uid)
    var editando by remember { mutableStateOf<ServicoDto?>(null) }
    var criando by remember { mutableStateOf(false) }
    LaunchedEffect(vm.busca) { if (vm.busca.isNotEmpty()) delay(300); vm.servicos.load() }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenTitle("Serviços", "Gerencie os serviços oferecidos") {
            Button(onClick = { criando = true }, shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = C.Primary)) {
                Icon(Icons.Filled.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Adicionar")
            }
        }
        OutlinedTextField(
            value = vm.busca, onValueChange = { vm.busca = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Buscar serviços...", color = C.Muted) }, leadingIcon = { Icon(Icons.Filled.Search, null, tint = C.Muted) },
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, focusedBorderColor = C.Primary, unfocusedBorderColor = C.Border)
        )
        Spacer(Modifier.height(12.dp))
        ResourceView(vm.servicos) { lista ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (lista.isEmpty()) EmptyState("Nenhum serviço encontrado.")
                lista.forEach { s ->
                    AppCard(onClick = { editando = s }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(s.nome, fontWeight = FontWeight.Bold, color = if (s.ativo) C.Text else C.Muted)
                                Text("${s.duracaoMinutos} min • ${s.preco.brl()}", fontSize = 13.sp, color = C.Muted)
                                Pill(s.categoria, C.CyanBg, C.Primary, Modifier.padding(top = 6.dp))
                            }
                            Switch(checked = s.ativo, onCheckedChange = { vm.ativarServico(s, it) },
                                colors = SwitchDefaults.colors(checkedTrackColor = C.Primary))
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
    if (criando) ServicoDialog(null, vm) { criando = false }
    editando?.let { ServicoDialog(it, vm) { editando = null } }
}

@Composable
private fun ServicoDialog(s: ServicoDto?, vm: AdminVM, onClose: () -> Unit) {
    var nome by remember { mutableStateOf(s?.nome ?: "") }
    var desc by remember { mutableStateOf(s?.descricao ?: "") }
    var cat by remember { mutableStateOf(s?.categoria ?: CATEGORIAS.first().first) }
    var dur by remember { mutableStateOf(s?.duracaoMinutos?.toString() ?: "60") }
    var preco by remember { mutableStateOf(s?.preco?.let { "%.2f".format(PT_BR, it) } ?: "") }
    AppDialog(if (s == null) "Novo serviço" else "Editar serviço", onClose) {
        AppField(nome, { nome = it }, "Nome")
        Spacer(Modifier.height(12.dp))
        AppField(desc, { desc = it }, "Descrição (opcional)")
        Spacer(Modifier.height(12.dp))
        DropdownField("Categoria", cat, CATEGORIAS.map { it.first }, { cat = it })
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppField(dur, { dur = it.filter(Char::isDigit) }, "Duração (min)", Modifier.weight(1f), keyboard = KeyboardType.Number)
            AppField(preco, { preco = it }, "Preço (R$)", Modifier.weight(1f), keyboard = KeyboardType.Decimal)
        }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppButton("Cancelar", onClose, Modifier.weight(1f), kind = BtnKind.Soft)
            AppButton("Salvar", {
                val d = dur.toIntOrNull()
                val p = preco.replace(',', '.').toDoubleOrNull()
                when {
                    nome.isBlank() -> Graph.toast("Informe o nome do serviço")
                    d == null || d < 5 -> Graph.toast("Duração mínima de 5 minutos")
                    p == null || p < 0 -> Graph.toast("Informe um preço válido")
                    else -> vm.gravarServico(s?.id, ServicoForm(nome.trim(), desc.trim().ifBlank { null }, cat, d, p), onClose)
                }
            }, Modifier.weight(1f), loading = vm.working)
        }
    }
}

// ------------------------------------------------------------------ Equipe (RN005)

@Composable
fun EquipeTab(uid: Long) {
    val vm: AdminVM = userVm(uid)
    LaunchedEffect(Unit) { vm.equipe.load() }
    var editando by remember { mutableStateOf<ProfissionalDto?>(null) }
    var criando by remember { mutableStateOf(false) }
    var horarios by remember { mutableStateOf<ProfissionalDto?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenTitle("Profissionais", "Gerencie a equipe e os horários") {
            Button(onClick = { criando = true }, shape = RoundedCornerShape(12.dp), colors = ButtonDefaults.buttonColors(containerColor = C.Primary)) {
                Icon(Icons.Filled.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Adicionar")
            }
        }
        ResourceView(vm.equipe) { lista ->
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (lista.isEmpty()) EmptyState("Nenhum profissional cadastrado.")
                lista.forEach { p ->
                    AppCard(onClick = { editando = p }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(p.nome, 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.nome, fontWeight = FontWeight.Bold, color = if (p.ativo) C.Text else C.Muted)
                                Text("${p.especialidade} • ${p.email}", fontSize = 12.sp, color = C.Muted, maxLines = 1)
                            }
                            Switch(checked = p.ativo, onCheckedChange = { vm.ativarProfissional(p, it) }, colors = SwitchDefaults.colors(checkedTrackColor = C.Primary))
                        }
                        TextButton(onClick = { horarios = p }) { Icon(Icons.Filled.Schedule, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text("Horários de atendimento", color = C.Primary) }
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
    if (criando) ProfissionalDialog(null, vm) { criando = false }
    editando?.let { ProfissionalDialog(it, vm) { editando = null } }
    horarios?.let { HorariosDialog(it, vm) { horarios = null } }
}

@Composable
private fun ProfissionalDialog(p: ProfissionalDto?, vm: AdminVM, onClose: () -> Unit) {
    var nome by remember { mutableStateOf(p?.nome ?: "") }
    var email by remember { mutableStateOf(p?.email ?: "") }
    var tel by remember { mutableStateOf(p?.telefone ?: "") }
    var esp by remember { mutableStateOf(p?.especialidade ?: CATEGORIAS.first().first) }
    var senha by remember { mutableStateOf("") }
    AppDialog(if (p == null) "Novo profissional" else "Editar profissional", onClose) {
        AppField(nome, { nome = it }, "Nome")
        Spacer(Modifier.height(12.dp))
        AppField(email, { email = it }, "E-mail", enabled = p == null, keyboard = KeyboardType.Email)
        Spacer(Modifier.height(12.dp))
        AppField(tel, { tel = it }, "Telefone (opcional)", keyboard = KeyboardType.Phone)
        Spacer(Modifier.height(12.dp))
        DropdownField("Especialidade (categoria de serviços)", esp, CATEGORIAS.map { it.first }, { esp = it })
        Spacer(Modifier.height(12.dp))
        AppField(senha, { senha = it }, if (p == null) "Senha inicial" else "Nova senha (opcional)", password = true)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AppButton("Cancelar", onClose, Modifier.weight(1f), kind = BtnKind.Soft)
            AppButton("Salvar", {
                when {
                    nome.isBlank() || email.isBlank() -> Graph.toast("Informe nome e e-mail")
                    p == null && senha.length < 6 -> Graph.toast("A senha inicial deve ter no mínimo 6 caracteres")
                    senha.isNotEmpty() && senha.length < 6 -> Graph.toast("A senha deve ter no mínimo 6 caracteres")
                    else -> vm.gravarProfissional(p?.id, ProfissionalForm(nome.trim(), email.trim(), tel.trim().ifBlank { null }, esp, senha.ifBlank { null }), onClose)
                }
            }, Modifier.weight(1f), loading = vm.working)
        }
    }
}

private val DIAS_SEMANA = listOf(
    "MONDAY" to "Segunda", "TUESDAY" to "Terça", "WEDNESDAY" to "Quarta", "THURSDAY" to "Quinta",
    "FRIDAY" to "Sexta", "SATURDAY" to "Sábado", "SUNDAY" to "Domingo"
)

@Composable
private fun HorariosDialog(p: ProfissionalDto, vm: AdminVM, onClose: () -> Unit) {
    var carregado by remember { mutableStateOf(false) }
    val ativos = remember { mutableStateMapOf<String, Boolean>() }
    val inicios = remember { mutableStateMapOf<String, String>() }
    val fins = remember { mutableStateMapOf<String, String>() }

    LaunchedEffect(p.id) {
        Api.call { adminDisponibilidade(p.id) }.fold(
            onSuccess = { lista ->
                lista.groupBy { it.diaSemana }.forEach { (dia, janelas) ->
                    ativos[dia] = true; inicios[dia] = janelas.first().horaInicio; fins[dia] = janelas.first().horaFim
                }
                carregado = true
            },
            onFailure = { Graph.toast(it.message ?: "Erro ao carregar horários"); onClose() }
        )
    }

    AppDialog("Horários de ${firstName(p.nome)}", onClose) {
        if (!carregado) CenterLoadingInline()
        else {
            DIAS_SEMANA.forEach { (chave, rotulo) ->
                val on = ativos[chave] == true
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = on, onCheckedChange = {
                        ativos[chave] = it
                        if (it && inicios[chave] == null) { inicios[chave] = "09:00"; fins[chave] = "18:00" }
                    }, colors = SwitchDefaults.colors(checkedTrackColor = C.Primary))
                    Text(rotulo, Modifier.width(76.dp).padding(start = 8.dp), fontSize = 13.sp, color = if (on) C.Text else C.Muted)
                    if (on) {
                        DropdownField("", inicios[chave] ?: "09:00", HORARIOS_PADRAO, { inicios[chave] = it }, Modifier.weight(1f))
                        Spacer(Modifier.width(6.dp))
                        DropdownField("", fins[chave] ?: "18:00", HORARIOS_PADRAO, { fins[chave] = it }, Modifier.weight(1f))
                    } else Text("Folga", color = C.Muted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                AppButton("Cancelar", onClose, Modifier.weight(1f), kind = BtnKind.Soft)
                AppButton("Salvar", {
                    val lista = DIAS_SEMANA.filter { ativos[it.first] == true }.map {
                        DisponibilidadeDto(it.first, inicios[it.first] ?: "09:00", fins[it.first] ?: "18:00")
                    }
                    if (lista.any { it.horaFim <= it.horaInicio }) Graph.toast("O horário final deve ser depois do inicial")
                    else vm.gravarHorarios(p.id, lista, onClose)
                }, Modifier.weight(1f), loading = vm.working)
            }
        }
    }
}

@Composable
private fun CenterLoadingInline() {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = C.Primary) }
}

// ------------------------------------------------------------------ Relatórios (RF002)

@Composable
fun RelatoriosScreen(uid: Long, onBack: () -> Unit) {
    val vm: AdminVM = userVm(uid)
    LaunchedEffect(Unit) { vm.relatorio.load() }
    val periodos = listOf("hoje" to "Hoje", "7" to "7 dias", "mes" to "Mês atual", "30" to "30 dias")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = C.Title) }
            Text("Relatórios de Desempenho", fontFamily = Outfit, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = C.Text)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            periodos.forEach { (k, label) -> FilterChip(selected = vm.periodo == k, onClick = { vm.trocarPeriodo(k) }, label = { Text(label) }) }
        }
        ResourceView(vm.relatorio) { r ->
            Text("${r.inicio.toDate().fmtShort()} a ${r.fim.toDate().fmtShort()}", color = C.Muted, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Resumo("Total", "${r.total}", C.Primary, Modifier.weight(1f))
                Resumo("Realizados", "${r.realizados}", C.GreenFg, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Resumo("Confirmados", "${r.confirmados}", C.Primary, Modifier.weight(1f))
                Resumo("Pendentes", "${r.pendentes}", C.AmberFg, Modifier.weight(1f))
                Resumo("Cancelados", "${r.cancelados}", C.RedFg, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            AppCard {
                Text("Receita dos atendimentos realizados", fontSize = 12.sp, color = C.Muted)
                Text(r.receita.brl(), fontFamily = Outfit, fontSize = 26.sp, fontWeight = FontWeight.Bold, color = C.Primary)
            }
            SectionTitle("Agendamentos do período")
            if (r.itens.isEmpty()) EmptyState("Nenhum agendamento no período.")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                r.itens.forEach { a ->
                    AppCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${a.data.toDate().fmtDiaMes()} • ${a.horaInicio}", Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 13.sp, color = C.Text)
                            StatusChip(a.status)
                        }
                        Text(a.servico, fontWeight = FontWeight.SemiBold, color = C.Text, modifier = Modifier.padding(top = 4.dp))
                        Text("${a.cliente} → ${a.profissional}", fontSize = 12.sp, color = C.Muted)
                        Text(a.valor.brl(), fontSize = 12.sp, color = C.Primary)
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun Resumo(titulo: String, valor: String, cor: Color, modifier: Modifier) {
    AppCard(modifier) {
        Text(titulo, fontSize = 11.sp, color = C.Muted, maxLines = 1)
        Text(valor, fontFamily = Outfit, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = cor)
    }
}
