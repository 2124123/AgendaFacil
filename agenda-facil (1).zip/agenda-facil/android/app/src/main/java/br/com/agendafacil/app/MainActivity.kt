package br.com.agendafacil.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import br.com.agendafacil.app.data.Graph
import br.com.agendafacil.app.ui.AgendaTheme
import br.com.agendafacil.app.ui.C
import br.com.agendafacil.app.ui.admin.AdminShell
import br.com.agendafacil.app.ui.auth.LoginScreen
import br.com.agendafacil.app.ui.auth.RegisterScreen
import br.com.agendafacil.app.ui.cliente.ClienteShell
import br.com.agendafacil.app.ui.profissional.ProfissionalShell

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        )
        setContent {
            AgendaTheme {
                AppRoot()
            }
        }
    }
}

@Composable
fun AppRoot() {
    val session by Graph.session.state.collectAsState()
    var registering by rememberSaveable { mutableStateOf(false) }
    val s = session
    androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().background(C.Bg)) {
        when {
            s == null && registering -> RegisterScreen(onBack = { registering = false })
            s == null -> LoginScreen(onRegister = { registering = true })
            s.usuario.perfil == "PROFISSIONAL" -> ProfissionalShell(s)
            s.usuario.perfil == "ADMINISTRADOR" -> AdminShell(s)
            else -> ClienteShell(s)
        }
    }
}
