package br.com.agendafacil.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import br.com.agendafacil.app.R
import br.com.agendafacil.app.data.Resource
import br.com.agendafacil.app.data.Ui
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

enum class BtnKind { Primary, Soft, Danger, Outline }

@Composable
fun AppButton(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier,
    enabled: Boolean = true, loading: Boolean = false, kind: BtnKind = BtnKind.Primary
) {
    val bg: Color
    val fg: Color
    when (kind) {
        BtnKind.Primary -> { bg = C.Primary; fg = Color.White }
        BtnKind.Soft -> { bg = C.CyanBg; fg = C.Primary }
        BtnKind.Danger -> { bg = C.RedBg; fg = C.RedFg }
        BtnKind.Outline -> { bg = Color.White; fg = C.Primary }
    }
    Button(
        onClick = onClick,
        enabled = enabled && !loading,
        modifier = modifier.fillMaxWidth().height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = bg, contentColor = fg,
            disabledContainerColor = bg.copy(alpha = 0.55f), disabledContentColor = fg.copy(alpha = 0.8f)
        ),
        border = if (kind == BtnKind.Outline) BorderStroke(1.dp, C.Primary) else null
    ) {
        if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = fg, strokeWidth = 2.dp)
        else Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

@Composable
fun FieldLabel(text: String) {
    Text(text, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = C.Title)
    Spacer(Modifier.height(6.dp))
}

@Composable
fun AppField(
    value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier,
    placeholder: String = "", leading: ImageVector? = null, password: Boolean = false,
    keyboard: KeyboardType = KeyboardType.Text, enabled: Boolean = true
) {
    var visible by remember { mutableStateOf(false) }
    val leadingContent: (@Composable () -> Unit)? =
        if (leading != null) ({ Icon(leading, null, tint = C.Muted) }) else null
    val trailingContent: (@Composable () -> Unit)? =
        if (password) ({
            IconButton(onClick = { visible = !visible }) {
                Icon(if (visible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, null, tint = C.Muted)
            }
        }) else null
    Column(modifier) {
        if (label.isNotEmpty()) FieldLabel(label)
        OutlinedTextField(
            value = value, onValueChange = onChange, enabled = enabled, singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(placeholder, color = C.Muted) },
            leadingIcon = leadingContent, trailingIcon = trailingContent,
            visualTransformation = if (password && !visible) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
                disabledContainerColor = C.Bg,
                focusedBorderColor = C.Primary, unfocusedBorderColor = C.Border,
                disabledBorderColor = C.Border, disabledTextColor = C.Muted
            )
        )
    }
}

@Composable
fun AppCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    if (onClick != null) {
        Surface(
            onClick = onClick, modifier = modifier.fillMaxWidth(), shape = shape, color = Color.White,
            border = BorderStroke(1.dp, C.Border), shadowElevation = 1.dp
        ) { Column(Modifier.padding(16.dp), content = content) }
    } else {
        Surface(
            modifier = modifier.fillMaxWidth(), shape = shape, color = Color.White,
            border = BorderStroke(1.dp, C.Border), shadowElevation = 1.dp
        ) { Column(Modifier.padding(16.dp), content = content) }
    }
}

@Composable
fun Pill(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier) {
    Text(
        text, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = fg,
        modifier = modifier.background(bg, RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

@Composable
fun StatusChip(status: String, modifier: Modifier = Modifier) {
    when (status) {
        "CONFIRMADO" -> Pill("Confirmado", C.GreenBg, C.GreenFg, modifier)
        "PENDENTE" -> Pill("Pendente", C.AmberBg, C.AmberFg, modifier)
        "CANCELADO" -> Pill("Cancelado", C.RedBg, C.RedFg, modifier)
        "REALIZADO" -> Pill("Realizado", C.CyanBg, C.Primary, modifier)
        else -> Pill(status, C.Border, C.Muted, modifier)
    }
}

private val avatarColors = listOf(
    Color(0xFF0891B2), Color(0xFFFF7F5C), Color(0xFF0E7490), Color(0xFF7C3AED), Color(0xFF059669), Color(0xFFD97706)
)

/** Fotos do protótipo do Figma (dados de demonstração). Sem foto cadastrada, mostra as iniciais. */
private val FOTOS: Map<String, Int> = mapOf(
    "ana paula" to R.drawable.foto_ana, "mariana costa" to R.drawable.foto_mariana,
    "carlos souza" to R.drawable.foto_carlos, "beatriz xavier" to R.drawable.foto_beatriz,
    "juliana prado" to R.drawable.foto_juliana
)

@Composable
fun Avatar(name: String, size: Dp = 44.dp) {
    val foto = FOTOS[name.trim().lowercase()]
    if (foto != null) {
        Image(painterResource(foto), name, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
        return
    }
    val initials = name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }
    Box(
        Modifier.size(size).clip(CircleShape).background(avatarColors[Math.abs(name.hashCode()) % avatarColors.size]),
        contentAlignment = Alignment.Center
    ) { Text(initials, color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.36f).sp) }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontFamily = Outfit, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = C.Text)
            if (subtitle != null) Text(subtitle, fontSize = 13.sp, color = C.Muted)
        }
        trailing()
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text, fontFamily = Outfit, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = C.Text, modifier = modifier.padding(top = 20.dp, bottom = 10.dp))
}

@Composable
fun CenterLoading(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize().padding(40.dp), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = C.Primary)
    }
}

@Composable
fun ErrorState(message: String, onRetry: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(message, color = C.RedFg, fontSize = 14.sp)
        Spacer(Modifier.height(12.dp))
        TextButton(onClick = onRetry) { Text("Tentar novamente", color = C.Primary) }
    }
}

@Composable
fun EmptyState(text: String) {
    Text(text, color = C.Muted, fontSize = 14.sp, modifier = Modifier.fillMaxWidth().padding(vertical = 32.dp, horizontal = 8.dp))
}

/** Mostra carregando / erro / conteúdo conforme o estado do [Resource]. */
@Composable
fun <T> ResourceView(res: Resource<T>, content: @Composable (T) -> Unit) {
    val state by res.state.collectAsState()
    when (val s = state) {
        is Ui.Loading -> CenterLoading()
        is Ui.Error -> ErrorState(s.message) { res.load() }
        is Ui.Data -> content(s.value)
    }
}

class NavItem(val label: String, val icon: ImageVector, val badge: Int = 0)

@Composable
fun AppBottomBar(items: List<NavItem>, selected: Int, onSelect: (Int) -> Unit) {
    NavigationBar(containerColor = Color.White) {
        items.forEachIndexed { i, item ->
            NavigationBarItem(
                selected = selected == i, onClick = { onSelect(i) },
                icon = {
                    if (item.badge > 0) BadgedBox(badge = { Badge(containerColor = C.Coral) { Text("${item.badge}") } }) { Icon(item.icon, item.label) }
                    else Icon(item.icon, item.label)
                },
                label = { Text(item.label, fontSize = 11.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = C.Primary, selectedTextColor = C.Primary, indicatorColor = Color.Transparent,
                    unselectedIconColor = C.Muted, unselectedTextColor = C.Muted
                )
            )
        }
    }
}

@Composable
fun AppDialog(title: String, onDismiss: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            Modifier.padding(horizontal = 20.dp).fillMaxWidth().heightIn(max = 640.dp),
            shape = RoundedCornerShape(20.dp), color = Color.White
        ) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp)) {
                Text(title, fontFamily = Outfit, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = C.Title)
                Spacer(Modifier.height(14.dp))
                content()
            }
        }
    }
}

@Composable
fun ConfirmDialog(title: String, message: String, confirmText: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color.White,
        title = { Text(title, fontWeight = FontWeight.Bold, color = C.Title) },
        text = { Text(message, color = C.Text) },
        confirmButton = { TextButton(onClick = onConfirm) { Text(confirmText, color = C.RedFg, fontWeight = FontWeight.SemiBold) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Voltar", color = C.Muted) } }
    )
}

@Composable
fun DropdownField(label: String, value: String, options: List<String>, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var aberto by remember { mutableStateOf(false) }
    Column(modifier) {
        if (label.isNotEmpty()) FieldLabel(label)
        Box {
            Surface(
                onClick = { aberto = true }, shape = RoundedCornerShape(12.dp), color = Color.White,
                border = BorderStroke(1.dp, C.Border), modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Row(Modifier.padding(start = 16.dp, end = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(value, Modifier.weight(1f), color = C.Text)
                    Icon(Icons.Filled.ArrowDropDown, null, tint = C.Muted)
                }
            }
            DropdownMenu(expanded = aberto, onDismissRequest = { aberto = false }) {
                options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { onSelect(o); aberto = false }) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(label: String, value: LocalDate, onChange: (LocalDate) -> Unit, modifier: Modifier = Modifier, minDate: LocalDate = hoje()) {
    var aberto by remember { mutableStateOf(false) }
    Column(modifier) {
        if (label.isNotEmpty()) FieldLabel(label)
        Surface(
            onClick = { aberto = true }, shape = RoundedCornerShape(12.dp), color = Color.White,
            border = BorderStroke(1.dp, C.Border), modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.CalendarMonth, null, tint = C.Muted)
                Spacer(Modifier.width(10.dp))
                Text(value.fmtShort(), color = C.Text)
            }
        }
    }
    if (aberto) {
        val minMillis = minDate.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val state = rememberDatePickerState(
            initialSelectedDateMillis = value.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli(),
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long): Boolean = utcTimeMillis >= minMillis
            }
        )
        DatePickerDialog(
            onDismissRequest = { aberto = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                    aberto = false
                }) { Text("OK", color = C.Primary) }
            },
            dismissButton = { TextButton(onClick = { aberto = false }) { Text("Cancelar", color = C.Muted) } }
        ) { DatePicker(state = state) }
    }
}

/** Horários de 30 em 30 minutos, de 06:00 a 22:00. */
val HORARIOS_PADRAO: List<String> = (12..44).map { "%02d:%02d".format(it / 2, (it % 2) * 30) }
