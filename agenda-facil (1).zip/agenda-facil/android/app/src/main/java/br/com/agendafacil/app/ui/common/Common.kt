package br.com.agendafacil.app.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import br.com.agendafacil.app.data.*
import br.com.agendafacil.app.ui.*
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ Perfil (RF001: manter cadastro)

class ProfileVM : ViewModel() {
    var saving by mutableStateOf(false)

    fun salvar(nome: String, telefone: String) {
        if (nome.isBlank()) { Graph.toast("Informe o nome"); return }
        viewModelScope.launch {
            saving = true
            Api.call { atualizarPerfil(PerfilUpdate(nome.trim(), telefone.trim().ifBlank { null })) }
                .fold({ Graph.session.updateUser(it); Graph.toast("Dados atualizados") }, { Graph.toast(it.message ?: "Erro ao salvar") })
            saving = false
        }
    }
}

@Composable
fun ProfileScreen(session: SessionData, onNotifications: (() -> Unit)? = null) {
    val u = session.usuario
    val vm: ProfileVM = userVm(u.id)
    var nome by rememberSaveable(u.id) { mutableStateOf(u.nome) }
    var tel by rememberSaveable(u.id) { mutableStateOf(u.telefone ?: "") }
    var sair by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        ScreenTitle("Perfil")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Avatar(u.nome, 64.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(u.nome, fontWeight = FontWeight.Bold, fontFamily = Outfit, fontSize = 18.sp, color = C.Text)
                Text(u.email, color = C.Muted, fontSize = 13.sp)
                Pill(perfilLabel(u.perfil), C.CyanBg, C.Primary, Modifier.padding(top = 6.dp))
            }
        }
        Spacer(Modifier.height(24.dp))
        AppField(nome, { nome = it }, "Nome", leading = Icons.Filled.Person)
        Spacer(Modifier.height(14.dp))
        AppField(tel, { tel = it }, "Telefone", leading = Icons.Filled.Phone, keyboard = KeyboardType.Phone)
        Spacer(Modifier.height(14.dp))
        AppField(u.email, {}, "E-mail", leading = Icons.Filled.Email, enabled = false)
        Spacer(Modifier.height(20.dp))
        AppButton("Salvar alterações", { vm.salvar(nome, tel) }, loading = vm.saving)
        if (onNotifications != null) {
            Spacer(Modifier.height(12.dp))
            AppButton("Notificações", onNotifications, kind = BtnKind.Soft)
        }
        Spacer(Modifier.height(12.dp))
        AppButton("Sair da conta", { sair = true }, kind = BtnKind.Danger)
        Spacer(Modifier.height(24.dp))
    }
    if (sair) ConfirmDialog("Sair da conta", "Deseja realmente sair?", "Sair", { sair = false; Graph.session.clear() }, { sair = false })
}

// ------------------------------------------------------------------ Central de notificações

class NotifVM : ViewModel() {
    val lista = Resource(viewModelScope) { notificacoes() }

    fun marcar(n: NotificacaoDto) {
        if (n.lida) return
        viewModelScope.launch { Api.call { marcarLida(n.id) }; lista.load() }
    }

    fun marcarTodas() {
        viewModelScope.launch { Api.call { marcarTodasLidas() }; lista.load() }
    }

    fun naoLidas(): Int = lista.dataOrNull?.count { !it.lida } ?: 0
}

private fun iconeNotif(tipo: String): Triple<ImageVector, Color, Color> = when (tipo) {
    "LEMBRETE" -> Triple(Icons.Filled.Notifications, C.CoralBg, C.Coral)
    "CANCELAMENTO" -> Triple(Icons.Filled.Block, C.RedBg, C.RedFg)
    "CONFIRMACAO" -> Triple(Icons.Filled.Check, C.GreenBg, C.GreenFg)
    "REMARCACAO" -> Triple(Icons.Filled.Update, C.AmberBg, C.AmberFg)
    else -> Triple(Icons.Filled.CalendarMonth, C.CyanBg, C.Primary)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificacoesScreen(vm: NotifVM, onClose: (() -> Unit)? = null) {
    LaunchedEffect(Unit) { vm.lista.load() }
    val refreshing by vm.lista.refreshing.collectAsState()
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        ScreenTitle("Central de Notificações", trailing = {
            if (onClose != null) IconButton(onClick = onClose) { Icon(Icons.Filled.Close, "Fechar", tint = C.Title) }
        })
        TextButton(onClick = { vm.marcarTodas() }) { Text("Marcar todas como lidas", color = C.Primary, fontSize = 13.sp) }
        PullToRefreshBox(isRefreshing = refreshing, onRefresh = { vm.lista.load() }, modifier = Modifier.weight(1f)) {
            ResourceView(vm.lista) { lista ->
                if (lista.isEmpty()) EmptyState("Você não tem notificações.")
                else Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    lista.forEach { n ->
                        val (icon, bg, fg) = iconeNotif(n.tipo)
                        AppCard(onClick = { vm.marcar(n) }) {
                            Row(verticalAlignment = Alignment.Top) {
                                Box(Modifier.size(40.dp).background(bg, CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(icon, null, tint = fg, modifier = Modifier.size(20.dp))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(n.mensagem, fontSize = 14.sp, color = C.Text, fontWeight = if (n.lida) FontWeight.Normal else FontWeight.SemiBold)
                                    Text(tempoRelativo(n.criadaEm), fontSize = 12.sp, color = C.Muted, modifier = Modifier.padding(top = 4.dp))
                                }
                                if (!n.lida) Box(Modifier.padding(top = 6.dp).size(8.dp).background(C.Coral, CircleShape))
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }
}
