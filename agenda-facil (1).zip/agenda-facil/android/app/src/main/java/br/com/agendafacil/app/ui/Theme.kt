package br.com.agendafacil.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.material3.Typography
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import br.com.agendafacil.app.R

/** Fontes do Figma: Outfit (títulos) e DM Sans (textos). Fontes variáveis (API 26+). */
val Outfit = FontFamily(listOf(400, 500, 600, 700).map { Font(R.font.outfit, FontWeight(it)) })
val DmSans = FontFamily(listOf(400, 500, 600, 700).map { Font(R.font.dmsans, FontWeight(it)) })

/** Paleta extraída do protótipo do Figma. */
object C {
    val Primary = Color(0xFF0891B2)
    val Title = Color(0xFF134E5E)
    val Coral = Color(0xFFFF7F5C)
    val CoralBg = Color(0xFFFFEDE8)
    val Bg = Color(0xFFF8FAFC)
    val Border = Color(0xFFE2E8F0)
    val Text = Color(0xFF0F172A)
    val Muted = Color(0xFF64748B)
    val CyanBg = Color(0xFFECFEFF)
    val GreenBg = Color(0xFFDCFCE7)
    val GreenFg = Color(0xFF15803D)
    val AmberBg = Color(0xFFFEF3C7)
    val AmberFg = Color(0xFFB45309)
    val RedBg = Color(0xFFFEE2E2)
    val RedFg = Color(0xFFB91C1C)
}

@Composable
fun AgendaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = C.Primary, onPrimary = Color.White,
            secondary = C.Coral, onSecondary = Color.White,
            background = C.Bg, onBackground = C.Text,
            surface = Color.White, onSurface = C.Text,
            surfaceVariant = C.CyanBg, outline = C.Border, error = C.RedFg
        ),
        typography = Typography(bodyLarge = TextStyle(fontFamily = DmSans, fontSize = 16.sp)),
        content = content
    )
}
