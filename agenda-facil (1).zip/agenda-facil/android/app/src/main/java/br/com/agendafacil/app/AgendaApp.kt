package br.com.agendafacil.app

import android.app.Application
import br.com.agendafacil.app.data.Graph

class AgendaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Graph.init(this)
    }
}
