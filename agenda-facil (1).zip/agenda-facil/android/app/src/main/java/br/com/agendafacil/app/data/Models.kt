package br.com.agendafacil.app.data

data class LoginReq(val email: String, val senha: String, val perfil: String?)
data class RegisterReq(val nome: String, val email: String, val telefone: String?, val senha: String)
data class UsuarioDto(val id: Long, val nome: String, val email: String, val telefone: String?, val perfil: String)
data class AuthRes(val token: String, val usuario: UsuarioDto, val estabelecimento: String?)
data class PerfilUpdate(val nome: String, val telefone: String?)

data class ServicoDto(
    val id: Long, val nome: String, val descricao: String?, val categoria: String,
    val duracaoMinutos: Int, val preco: Double, val ativo: Boolean
)
data class ServicoForm(val nome: String, val descricao: String?, val categoria: String, val duracaoMinutos: Int, val preco: Double)

data class ProfissionalDto(
    val id: Long, val nome: String, val email: String, val telefone: String?,
    val especialidade: String, val ativo: Boolean
)
data class ProfissionalForm(val nome: String, val email: String, val telefone: String?, val especialidade: String, val senha: String?)
data class DisponibilidadeDto(val diaSemana: String, val horaInicio: String, val horaFim: String)

data class AgendamentoReq(val profissionalId: Long, val servicoId: Long, val data: String, val horaInicio: String)
data class RemarcarReq(val data: String, val horaInicio: String)
data class AgendamentoDto(
    val id: Long, val servicoId: Long, val servico: String, val categoria: String,
    val profissionalId: Long, val profissional: String,
    val clienteId: Long, val cliente: String, val clienteTelefone: String?,
    val data: String, val horaInicio: String, val horaFim: String,
    val status: String, val valor: Double, val local: String?, val endereco: String?
)
data class DiaDisponivelDto(val data: String, val horarios: Int)

data class BloqueioReq(val data: String, val horaInicio: String, val horaFim: String, val motivo: String?)
data class BloqueioDto(val id: Long, val data: String, val horaInicio: String, val horaFim: String, val motivo: String?)
data class AgendaDto(val agendamentos: List<AgendamentoDto>, val bloqueios: List<BloqueioDto>)
data class ClienteResumoDto(
    val id: Long, val nome: String, val telefone: String?, val email: String,
    val atendimentos: Long, val ultimoAtendimento: String?
)

data class NotificacaoDto(val id: Long, val tipo: String, val mensagem: String, val lida: Boolean, val criadaEm: String)

data class ProfissionalResumoDto(val id: Long, val nome: String, val especialidade: String, val agendamentosHoje: Long)
data class DashboardDto(
    val estabelecimento: String, val agendamentosHoje: Long, val variacaoPercentual: Int?,
    val taxaOcupacao: Int, val semana: List<Int>, val profissionais: List<ProfissionalResumoDto>
)
data class RelatorioDto(
    val inicio: String, val fim: String, val total: Long, val pendentes: Long, val confirmados: Long,
    val realizados: Long, val cancelados: Long, val receita: Double, val itens: List<AgendamentoDto>
)

/** Sessão persistida no aparelho. */
data class SessionData(val token: String, val usuario: UsuarioDto, val estabelecimento: String)
